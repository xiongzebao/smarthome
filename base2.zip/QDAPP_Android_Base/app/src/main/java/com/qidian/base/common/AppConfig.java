package com.qidian.base.common;



public class AppConfig {
    /**
     * 是否是debug模式
     */
    public static final boolean IS_DEBUG = true;


    public static final String URI_AUTHORITY_BETA = "http://qdzx.qidiandev.cn";//测试服（2018/5/31）

    public static final String APP_KEY = "oQIhAP24Kb3Bsf7IE14wpl751bQc9VAPsFZ+LdB4riBgg2TDAiEAsSomOO1v8mK2VWhEQh6mttgN";

    public static final String APP_SECRET = "4C5A989C9DC6BF46B2F63F0E16EB1B78";

}

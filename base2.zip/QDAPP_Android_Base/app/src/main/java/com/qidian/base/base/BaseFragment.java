package com.qidian.base.base;

import android.support.v4.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;

public class BaseFragment extends Fragment {

}

package com.qidian.kuaitui.module.main;

import androidx.databinding.DataBindingUtil;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qidian.base.base.BaseFragment;
import com.qidian.kuaitui.R;
import com.qidian.kuaitui.databinding.FragHomeBinding;

public class HomeFragment extends BaseFragment {

    FragHomeBinding binding;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.frag_home, null, false);
        return binding.getRoot();
    }
}

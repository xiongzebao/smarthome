package com.qidian.kuaitui;


import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;


import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;
import com.erongdu.wireless.tools.utils.ToastUtil;
import com.qidian.base.base.BaseActivity;
import com.qidian.kuaitui.databinding.ActivityMainBinding;

public class MainActivity extends BaseActivity {

    ActivityMainBinding binding;
    /**
     * 底部导航栏操作监听
     */
    public BottomNavigationBar.OnTabSelectedListener listener = new BottomNavigationBar.OnTabSelectedListener() {
        @Override
        public void onTabSelected(int position) {
            FragmentManager manager = MainActivity.this.getSupportFragmentManager();
            // 开启事务
            FragmentTransaction transaction = manager.beginTransaction();

            // 事务提交
            transaction.commitAllowingStateLoss();
        }

        @Override
        public void onTabUnselected(int position) {
            FragmentManager manager = MainActivity.this.getSupportFragmentManager();
            // 开启事务
            FragmentTransaction transaction = manager.beginTransaction();

            transaction.commitAllowingStateLoss();
        }

        @Override
        public void onTabReselected(int position) {

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        initTab();
    }

    private void initTab() {
        binding.tabs
                .setMode(BottomNavigationBar.MODE_FIXED)
                .setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_RIPPLE)
                .setActiveColor(R.color.white)
                .setInActiveColor(R.color.tab_text_normal)

                .setBarBackgroundColor(R.color.main_blue)
                .addItem(new BottomNavigationItem(R.drawable.menu_home_fill, "首页")//这里表示选中的图片
                        .setInactiveIcon(ContextCompat.getDrawable(this, R.drawable.menu_home)))
                .addItem(new BottomNavigationItem(R.drawable.menu_mail__fill, "在职")//这里表示选中的图片
                         .setInactiveIcon(ContextCompat.getDrawable(this, R.drawable.menu_book)))//非选中的图片)
                .addItem(new BottomNavigationItem(R.drawable.menu_user_fill, "我的")//这里表示选中的图片
                        .setInactiveIcon(ContextCompat.getDrawable(this, R.drawable.menu_user)))//非选中的图片)
                .setTabSelectedListener(listener)
                .setFirstSelectedPosition(0)
                .initialise();
        this.binding.tabs.selectTab(0);

    }


}
